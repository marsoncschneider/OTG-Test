function onUpdateDatabase()
    return false -- true = There are others migrations file | false = this is the last migration file
end
