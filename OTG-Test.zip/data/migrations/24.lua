function onUpdateDatabase()
	print("> Updating database")
	return true
end
